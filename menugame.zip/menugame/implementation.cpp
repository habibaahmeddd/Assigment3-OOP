#include <iostream>
#include <iomanip>
#include <algorithm>
#include"X0GAME.h"
using namespace std;

// Set the board
Pyramic_X_O_Board::Pyramic_X_O_Board(){
    n_rows =3,n_cols = 5;
    board = new char*[n_rows];
    for (int i = 0; i < n_rows; i++) {
        board [i] = new char[n_cols];
        for (int j = 0; j < n_cols; j++)
            board[i][j] = 0;
    }
}

bool Pyramic_X_O_Board::update_board(int x,int y,char mark) {
    if (((x == 0 && y == 2) || (x == 1 && y == 1) || (x == 1 && y == 2) || (x == 1 && y == 3) || (x == 2 && y == 0) ||
         (x == 2 && y == 1) || (x == 2 && y == 3) || (x == 2 && y == 4) || (x == 2 && y == 2)) && board[x][y] == 0) {
        board[x][y] = toupper(mark);
        ++n_moves;
        return true;
    } else  {
        return false;
    }
}
// Display the board and the pieces on it
void Pyramic_X_O_Board::display_board() {
    cout << "                  |(0, 2) " << board[0][2] << '|' << endl;
    cout << setw(28) << "----------" << endl;
    cout << "         |(1, 1) " << board[1][1] << "|(1, 2) " << board[1][2] << "|(1, 3) " << board[1][3] << '|' <<  endl;
    cout << "         ----------------------------" << endl;
    cout << "|(2, 0) " << board[2][0] << "|(2, 1) " << board[2][1] << "|(2, 2) " << board[2][2] << "|(2, 3) " << board[2][3] << "|(2, 4) " << board[2][4] << '|' << endl;
    cout << "----------------------------------------------" << endl;
}

bool Pyramic_X_O_Board::is_winner() {

    if (board[2][0] == board[2][1] && board[2][1] == board[2][2] && board[2][0] != 0) {
        return true;
    } else if (board[0][2] == board[1][1] && board[1][1] == board[2][0] && board[0][2] != 0) {
        return true;
    } else if (board[0][2] == board[1][2] && board[1][2] == board[2][2] && board[0][2] != 0) {
        return true;
    } else if (board[0][2] == board[1][3] && board[1][3] == board[2][4] && board[0][2] != 0) {
        return true;
    } else if (board[1][1] == board[1][2] && board[1][2] == board[1][3] && board[1][1] != 0) {
        return true;
    } else if (board[2][2] == board[2][3] && board[2][3] == board[2][4] && board[2][2] != 0) {
        return true;
    } else if (board[2][1] == board[2][2] && board[2][2] == board[2][3] && board[2][1] != 0) {
        return true;
    } else {
        return false;
    }
}
bool Pyramic_X_O_Board::is_draw(){
    return (n_moves == 9 && !is_winner());
}
bool Pyramic_X_O_Board::game_is_over() {
    return n_moves >= 9;
}
Four_in_row::Four_in_row () {
    n_rows = 6,n_cols = 7;
    board = new char*[n_rows];
    for (int i = 0; i < n_rows; i++) {
        board [i] = new char[n_cols];
        for (int j = 0; j < n_cols; j++)
            board[i][j] = 0;
    }
}

void Four_in_row::display_board() {
    for (int i: {0,1,2,3,4,5}) {
        cout << "\n| ";
        for (int j: {0,1,2,3,4,5,6}) {
            cout << "(" << i << "," << j << ")";
            cout << setw(2) << board [i][j] << " |";
        }
        cout << "\n--------------------------------------------------------------";
    }
    cout << endl;
}

bool Four_in_row::update_board (int x,int y, char mark){
    // Only update if move is valid
    int cnt = 5; //as x
    if (!( y < 0 || y > 6)){
        if (board[cnt][y] == 0){
            board[cnt][y] = toupper(mark);
            n_moves++;
            return true;
        }
        else{
            while (board[cnt][y] && cnt > 0){
                cnt--;
            }
            board[cnt][y] = toupper(mark);
            n_moves++;
            return true;
        }
    }
}

bool Four_in_row::is_winner(){
    char by_row,by_col,d1,d2;
    for (int i=5;i>=0;i--) {
        for(int j=0;j<4;j++) {
            by_row = board[i][j] & board[i][j + 1] & board[i][j + 2] & board[i][j + 3];
            if (by_row and by_row == board[i][j] )
                return true;
        }
    }

    for (int j=0;j<7;j++) {
        for(int i=0;i<3;i++)
        {
            by_col = board[i][j] & board[i+1][j] & board[i+2][j] & board[i+3][j];
            if (by_col and by_col == board[i][j] )
                return true;

        }
    }
    for (int i=0;i<3;i++) {
        for(int j=0;j<3;j++)
        {
            d1 = board[i][j] & board[i+1][j+1] & board[i+2][j+2] & board[i+3][j+3];
            if (d1 and d1 == board[i][j])
                return true;
        }
    }
    for (int i=5;i>=3;i--) {
        for(int j=0;j<4;j++)
        {
            d2 = board[i][j] & board[i-1][j+1] & board[i-2][j+2] & board[i-3][j+3];
            if (d2 and d2 == board[i][j] )
                return true;
        }
    }

    return false;
}

// Return true if 42 moves are done and no winner
bool Four_in_row::is_draw() {
    return (n_moves == 42 && !is_winner());
}

bool Four_in_row::game_is_over () {
    return n_moves >= 42;
}


//char Board::is_winner(char c) {}() {
//    return get
//}

void Board::set_symbol(char c) {
    _c=c;
}

char Board::get_symbol() {
    return _c;
}

// Set the board
int xCnt=0;
int yCnt=0;

TicTacToe5x5::TicTacToe5x5 () {
    n_rows = n_cols = 5;
    board = new char*[n_rows];
    for (int i = 0; i < n_rows; i++) {
        board [i] = new char[n_cols];
        for (int j = 0; j < n_cols; j++)
            board[i][j] = 0;
    }
}

// Return true  if move is valid and put it on board
// within board boundaries in empty cell
// Return false otherwise
bool TicTacToe5x5::update_board (int x, int y, char mark){
    // Only update if move is valid
    if (!(x < 0 || x > 4 || y < 0 || y > 4) && (board[x][y] == 0)) {
        board[x][y] = toupper(mark);
        n_moves++;
        return true;
    }
    else
        return false;
}

// Display the board and the pieces on it
void TicTacToe5x5::display_board() {
    for (int i: {0,1,2,3,4}) {
        cout << "\n| ";
        for (int j: {0,1,2,3,4}) {
            cout << "(" << i << "," << j << ")";
            cout << setw(4) << board [i][j] << " |";
        }
        cout << "\n----------------------------------------------------------";
    }
    cout << endl;
}

// Returns true if there is any winner
// either X or O
// Written in a complex way. DO NOT DO LIKE THIS.
bool TicTacToe5x5::is_winner() {
    char t=get_symbol();
//    int x=0;
//    int o=0;
    char row_win[15], col_win[15], diag_win[18];
    int tmp=0;
//    int tmpCol=0;
    for (int i:{0,1,2,3,4}) {
        for (int j:{0,1,2}) {
            row_win[tmp] = (board[i][j] & board[i][j + 1] & board[i][j + 2]);
        }
        tmp++;
    }
    tmp=0;
    for (int i:{0,1,2}) {
        for (int j:{0,1,2,3,4}) {
            col_win[tmp] = (board[i][j] & board[i+1][j] & board[i+2][j]);
        }
        tmp++;
    }
//    tmp=0;
//    for (int i:{0,1,2}) {
//        for (int j:{0,1,2,3,4}) {
//            diag_win[tmp] = (board[i][j] & board[i][j + 1] & board[i][j + 2]);
//        }
//        tmp++;
//    }

    for (int i:{0,1,2,3,4}) {
        if ( (row_win[i] && (row_win[i] == board[i][0])) ||
             (col_win[i] && (col_win[i] == board[0][i])) )
        {
            t=='x'?xCnt++:yCnt++;
            return true;
        }
    }
//    if ((diag_win[0] && diag_win[0] == board[1][1]) ||
//        (diag_win[1] && diag_win[1] == board[1][1]))
//        {return true;}
    return false;
}

// Return true if 24 moves are done and no winner
bool TicTacToe5x5::is_draw() {
    return (n_moves == 24 && (xCnt==yCnt));
}

bool TicTacToe5x5::game_is_over () {
    return n_moves >= 24;
}

X_O_Board::X_O_Board () {
    n_rows = n_cols = 3;
    board = new char*[n_rows];
    for (int i = 0; i < n_rows; i++) {
        board [i] = new char[n_cols];
        for (int j = 0; j < n_cols; j++)
            board[i][j] = 0;
    }
}

// Return true  if move is valid and put it on board
// within board boundaries in empty cell
// Return false otherwise
bool X_O_Board::update_board (int x, int y, char mark){
    // Only update if move is valid
    if (!(x < 0 || x > 2 || y < 0 || y > 2) && (board[x][y] == 0)

            ) {
        board[x][y] = toupper(mark);
        n_moves++;
        return true;
    }
    else
        return false;
}

// Display the board and the pieces on it
void X_O_Board::display_board() {
    for (int i: {0,1,2}) {
        cout << "\n| ";
        for (int j: {0,1,2}) {
            cout << "(" << i << "," << j << ")";
            cout << setw(2) << board [i][j] << " |";
        }
        cout << "\n-----------------------------";
    }
    cout << endl;
}

// Returns true if there is any winner
// either X or O
// Written in a complex way. DO NOT DO LIKE THIS.
bool X_O_Board::is_winner() {
    char row_win[3], col_win[3], diag_win[2];
    for (int i:{0,1,2}) {
        row_win[i] = board[i][0] & board[i][1] & board[i][2];
        col_win[i] = board[0][i] & board[1][i] & board[2][i];
    }
    diag_win[0] = board[0][0] & board[1][1] & board[2][2];
    diag_win[1] = board[2][0] & board[1][1] & board[0][2];

    for (int i:{0,1,2}) {
        if ( (row_win[i] && (row_win[i] == board[i][0])) ||
             (col_win[i] && (col_win[i] == board[0][i])) )
        {return true;}
    }
    if ((diag_win[0] && diag_win[0] == board[1][1]) ||
        (diag_win[1] && diag_win[1] == board[1][1]))
    {return true;}
    return false;
}

// Return true if 9 moves are done and no winner
bool X_O_Board::is_draw() {
    return (n_moves == 9 && !is_winner());
}

bool X_O_Board::game_is_over () {
    return n_moves >= 9;
}
//int X_O_Board::check_status()
//{
//    // Check rows and columns
//    for (int i = 0; i < 3; i++)
//    {
//        if (board[i][0] == board[i][1] && board[i][1] == board[i][2] && board[i][0] != 0)
//            return (board[i][0] == 'X') ? 2 : -2;  // 'X' wins: return 2, 'O' wins: return -2
//
//        if (board[0][i] == board[1][i] && board[1][i] == board[2][i] && board[0][i] != 0)
//            return (board[0][i] == 'X') ? 2 : -2;  // 'X' wins: return 2, 'O' wins: return -2
//    }
//
//    // Check diagonals
//    if (board[0][0] == board[1][1] && board[1][1] == board[2][2] && board[0][0] != 0)
//        return (board[0][0] == 'X') ? 2 : -2;  // 'X' wins: return 2, 'O' wins: return -2
//
//    if (board[0][2] == board[1][1] && board[1][1] == board[2][0] && board[0][2] != 0)
//        return (board[0][2] == 'X') ? 2 : -2;  // 'X' wins: return 2, 'O' wins: return -2
//
//    // Check for a draw
//    for (int i = 0; i < 3; i++)
//    {
//        for (int j = 0; j < 3; j++)
//        {
//            if (board[i][j] == 0)
//                return 1;  // Game still ongoing
//        }
//    }
//
//    // If no winner and no empty spaces, it's a draw
//    return 0;
//}

//int X_O_Board::minimax(int& x, int& y, bool isMaximizing, bool firstTime)
//{
//    int result = check_status();
//    if (result != 1)
//        return result;
//
//    int max_score = INT_MIN, min_score = INT_MAX;
//    int finalI, finalJ;
//
//    for (int i = 0; i < 3; i++)
//    {
//        for (int j = 0; j < 3; j++)
//        {
//            if (board[i][j] == 0)
//            {
//                if (isMaximizing)
//                {
//                    board[i][j] = 'X';
//                    int score = minimax(x, y, false, false);
//                    board[i][j] = 0;
//                    if (score >= max_score)
//                    {
//                        max_score = score;
//                        finalI = i;
//                        finalJ = j;
//                    }
//                    if (firstTime)
//                        cout << "in " << i << ", " << j << (score == 2 ? "X win" : (score == -2) ? "O win" : " Draw");
//                }
//                else
//                {
//                    board[i][j] = 'O';
//                    int score = minimax(x, y, true, false);
//                    board[i][j] = 0;
//                    if (score <= min_score)
//                    {
//                        min_score = score;
//                        finalI = i;
//                        finalJ = j;
//                    }
//                    if (firstTime)
//                        cout << "in " << i << ", " << j << (score == 2 ? " X win" : (score == -2) ? " O win" : " Draw") << '\n';
//                }
//            }
//        }
//    }
//
//    if (firstTime)
//        x = finalI, y = finalJ;
//    return (isMaximizing ? max_score : min_score);
//}


//Implementation for the Player class

Player::Player(char symbol) {
    this->symbol = symbol;
}

// Optionally, you can give him ID or order
// Like Player 1 and Player 2
Player::Player (int order, char symbol) {
    cout << "Welcome player " << order << endl;
    cout << "Please enter your name: ";
    cin >> name;
    this->symbol = symbol;
}

// Get desired move: x y (each between 0 and 2)
// Virtual (can change for other player types)
void Player::get_move (int& x, int& y) {
    cout << "\nPlease enter your move x and y (0 to 2) separated by spaces: ";
    cin >> x >> y;
}

// Give player info as a string
string Player::to_string(){
    return "Player: " + name ;
}

// Get symbol used by player
char Player::get_symbol() {
    return symbol;
}
int Player::get_cnt() {
    return cnt;
}

void Player::set_cnt(int x) {
    cnt=x;
}

// Implementation for the RandomPlayer class

RandomPlayer::RandomPlayer (char symbol, int dimension):Player(symbol)
{
    this->dimension = dimension;
    this->name = "Random Computer Player";
    cout << "My names is " << name << endl;
}

// Generate a random move
void RandomPlayer::get_move (int& x, int& y) {
    if(dimension==3) {
        x = (int) (rand() / (RAND_MAX + 1.0) * 3);
        if (x == 0) y = 0;
        else if (x == 1)
            y = (int) (rand() / (RAND_MAX + 1.0) * 3);
        else
            y = (int) (rand() / (RAND_MAX + 1.0) * 5);
    }
    x = (int) (rand()/(RAND_MAX + 1.0) * dimension);
    y = (int) (rand()/(RAND_MAX + 1.0) * dimension);


}


mypyramicRandomPlayer::mypyramicRandomPlayer(char symbol, int dimension):RandomPlayer(symbol,dimension){
    this->dimension = dimension;
    this->name = "Random Computer Player";
    cout << "My name is " << name << endl;
}

// Generate a random move
void mypyramicRandomPlayer::get_move(int& x, int& y) {
    x = static_cast<int>(rand() / (RAND_MAX + 1.0) * 3);
    y = static_cast<int>(rand() / (RAND_MAX + 1.0) * dimension);
}
// Set player symbol and name as Random Computer Player
RPlayer::RPlayer (char symbol, int dimension):RandomPlayer(symbol,dimension){
    this->dimension = dimension;
    this->name = "Random Computer Player";
    cout << "My name is " << name << endl;
}


// Generate a random move
void RPlayer::get_move ( int& x,int& y) {
    y = (int) (rand()/(RAND_MAX + 1.0) * dimension);
}

// Implementation for the GameManager class
GameManager::GameManager(Board* bPtr, Player* playerPtr[2] ) {
    boardPtr = bPtr;
    players[0] = playerPtr[0];
    players[1] = playerPtr[1];
}

void GameManager::run() {
    int x, y;

    boardPtr->display_board();

    while (!boardPtr->game_is_over()) {
        for (int i:{0,1}) {
            players[i]->get_move(x, y);
            while (!boardPtr->update_board (x, y, players[i]->get_symbol())){
                players[i]->get_move(x, y);
            }
            boardPtr->display_board();
            if (boardPtr->is_winner()){
                cout  << players[i]->to_string() << " wins\n";
                return;
            }
            if (boardPtr->is_draw()){
                cout << "Draw!\n";
                return;
            }
        }
    }
}
