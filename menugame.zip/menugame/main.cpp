
#include <iostream>
#include <cstdlib>
#include <ctime>
#include"X0GAME.h"

using namespace std;

int main() {
    // Seed for random number generation
    srand(static_cast<unsigned>(time(nullptr)));

    cout << "Welcome to the Board Game Menu!" << endl;
    cout << "Choose a game to play:" << endl;
    cout << "1. X_O game" << endl;
    cout << "2. Pyramic Tic Tac Toe" << endl;
    cout << "3. Four in a Row" << endl;
    cout << "4. Tic Tac Toe" << endl;



    int choice;
    cout << "Enter your choice (1-4): ";
    cin >> choice;

    Board* gameBoard = nullptr;
    Player* players[2];

    int c=1;
    switch (choice) {
        case 1:
            gameBoard=new X_O_Board();
            break;
        case 2:
            gameBoard = new Pyramic_X_O_Board(),c=0;
            break;
        case 3:
            gameBoard = new Four_in_row(),c=1;
            break;
        case 4:
            gameBoard = new TicTacToe5x5() ;
            break;
        default:
            cout << "Invalid choice. Exiting." << endl;
            return 1;
    }

    cout << "Choose your opponent:" << endl;
    cout << "1. Play against another player" << endl;
    cout << "2. Play against a random computer player" << endl;
    cout<<  "2. play against a smart computer player"<<endl;

    int Choice;
    cout << "Enter your choice (1-3): ";
    cin >> Choice;

    switch (Choice) {
        case 1:
            players[0] = new Player(1, 'X');
            players[1] = new Player(2, 'O');
            break;
        case 2:
            players[0] = new Player(1, 'X');
            if(c==0) {
                players[1] = new RandomPlayer('O', 5);
            }
            else if (c==1){
                players[1]=new RandomPlayer('O',7);
            }

            else {
                players[1] = new RandomPlayer('O', 5);
            }
            break;
//        case 3:
//            players[0] = new Player(1, 'X');
//            players[1] = new SmartPlayer(2, 'O');
//            break;
        default:
            cout << "Invalid choice. Exiting." << endl;
            delete gameBoard;
            return 1;
    }

    GameManager GameManager(gameBoard,players);
    GameManager.run();

    // Clean up dynamically allocated memory
    delete players[0];
    delete players[1];
    delete gameBoard;

    return 0;
}
