// Class definition for TicTacToe5x5 class
// Author:  Mohammad El-Ramly
// Date:    10/10/2022
// Version: 1
#include <iostream>
#include <random>
#include <iomanip>
#include <algorithm>
#include "../include/BoardGame_Classes.hpp"
#include "GameManager.cpp"
using namespace std;

//char Board::is_winner(char c) {}() {
//    return get
//}

void Board::set_symbol(char c) {
    _c=c;
}

char Board::get_symbol() {
    return _c;
}

// Set the board
TicTacToe5x5::TicTacToe5x5 () {
   n_rows = n_cols = 5;
   board = new char*[n_rows];
   for (int i = 0; i < n_rows; i++) {
      board [i] = new char[n_cols];
      for (int j = 0; j < n_cols; j++)
         board[i][j] = 0;
   }
}

// Return true  if move is valid and put it on board
// within board boundaries in empty cell
// Return false otherwise
bool TicTacToe5x5::update_board (int x, int y, char mark){
   // Only update if move is valid
   if (!(x < 0 || x > 4 || y < 0 || y > 4) && (board[x][y] == 0)) {
      board[x][y] = toupper(mark);
      n_moves++;
      return true;
   }
   else
      return false;
}

// Display the board and the pieces on it
void TicTacToe5x5::display_board() {
   for (int i: {0,1,2,3,4}) {
      cout << "\n| ";
      for (int j: {0,1,2,3,4}) {
         cout << "(" << i << "," << j << ")";
         cout << setw(4) << board [i][j] << " |";
      }
      cout << "\n----------------------------------------------------------";
   }
   cout << endl;
}

// Returns true if there is any winner
// either X or O
// Written in a complex way. DO NOT DO LIKE THIS.
bool TicTacToe5x5::is_winner() {
    char t=get_symbol();
//    int x=0;
//    int o=0;
    char row_win[15], col_win[15], diag_win[18];
    int tmp=0;
//    int tmpCol=0;
    for (int i:{0,1,2,3,4}) {
        for (int j:{0,1,2}) {
            row_win[tmp] = (board[i][j] & board[i][j + 1] & board[i][j + 2]);
        }
        tmp++;
    }
    tmp=0;
    for (int i:{0,1,2}) {
        for (int j:{0,1,2,3,4}) {
            col_win[tmp] = (board[i][j] & board[i+1][j] & board[i+2][j]);
        }
        tmp++;
    }
//    tmp=0;
//    for (int i:{0,1,2}) {
//        for (int j:{0,1,2,3,4}) {
//            diag_win[tmp] = (board[i][j] & board[i][j + 1] & board[i][j + 2]);
//        }
//        tmp++;
//    }

    for (int i:{0,1,2,3,4}) {
        if ( (row_win[i] && (row_win[i] == board[i][0])) ||
             (col_win[i] && (col_win[i] == board[0][i])) )
            {
                t=='x'?xCnt++:yCnt++;
                return true;
            }
    }
//    if ((diag_win[0] && diag_win[0] == board[1][1]) ||
//        (diag_win[1] && diag_win[1] == board[1][1]))
//        {return true;}
    return false;
}

// Return true if 24 moves are done and no winner
bool TicTacToe5x5::is_draw() {
    return (n_moves == 24 && (xCnt==yCnt));
}

bool TicTacToe5x5::game_is_over () {
    return n_moves >= 24;
}
